function myfunction(){
    var x = 1024;
    var y = 9999;
    
    var deg = Math.floor(Math.random() * (x - y)) + y;
    
     setTimeout(function(){ 
    modal.style.display = "block";
    }, 5000);
    
    var modal = document.getElementById("myModal");

    document.getElementById('box').style.transform = "rotate("+deg+"deg)";
    
    var element = document.getElementById('main');
    element.classList.remove('animate');
    setTimeout(function(){
        element.classList.add('animate');
    
    }, 3000);
    
    }

function openNav(){
    
    document.getElementById("mySidenav").style.width = "1000px";
}

function closeNav(){
    document.getElementById("mySidenav").style.width = "0";
}



